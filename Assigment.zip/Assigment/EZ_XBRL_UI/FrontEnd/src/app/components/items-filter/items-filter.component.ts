import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from  '@ngx-translate/core';
import { SharedDataService } from 'src/app/services/shared-data.service';
import { ConceptsService } from 'src/app/services/concepts.service';
import { ItemsListComponent } from 'src/app/components/items-list/items-list.component';

@Component({
  selector: 'app-items-filter',
  templateUrl: './items-filter.component.html',
  styleUrls: ['./items-filter.component.css']
})

export class ItemsFilterComponent implements OnInit {
  @ViewChild(ItemsListComponent) private _child  : ItemsListComponent;

  products: any;
  langauges: any;
  selectedConcept: any;
  selectedLanguage: any;

constructor(private conceptsService: ConceptsService, private router: Router, public translate: TranslateService, private sharedDataService: SharedDataService) { 
  translate.addLangs(['en', 'es']);
  translate.use('en')
}

  ngOnInit(): void {
    this.GetDistinctConcepts();
  }

  GetDistinctConcepts(): void {
    this.conceptsService.GetDistinctConcepts()
      .subscribe(
        products => {
          this.products = products;
        },
        error => {
          console.log(error);
        });
  }
 
  LoadItems(){    
    this.sharedDataService.SetSelectedConceptId(this.selectedConcept.concept_id);
    this.sharedDataService.SetSelectedLanguage(this.translate.currentLang);
    this._child.DisplayItems();
  }

  SwitchLanguage(lang: string) {    
    this.translate.use(lang);
    this.sharedDataService.SetSelectedConceptId(this.selectedConcept.concept_id);
    this.sharedDataService.SetSelectedLanguage(lang);   
    this._child.DisplayItems();
  }
}
