import { Component, OnInit } from '@angular/core';
import { ItemsService } from 'src/app/services/items.service';
import { Router  , ActivatedRoute } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { SharedDataService } from 'src/app/services/shared-data.service';

@Component({
  selector: 'app-items-list',
  templateUrl: './items-list.component.html',
  styleUrls: ['./items-list.component.css']
})

export class ItemsListComponent implements OnInit {

  products: any;
  currentProduct = null;
  currentIndex = -1;
  name = '';
  dataSource:any;

  constructor(private itemsService: ItemsService, private route: ActivatedRoute, private sharedDataService: SharedDataService) { }

  ngOnInit(): void {
  }

  //Call method of the child component
  DisplayItems(){ 
    const conceptId = this.sharedDataService.GetConceptId();
    const selectedLanguage = this.sharedDataService.GetSelectedLanguage();
    this.route.params.subscribe((params) => {this.GetItemsToDisplay(conceptId, selectedLanguage)});
   }

   GetItemsToDisplay(selectedComponent : any, selectedLanguage : any): void {
    this.itemsService.GetItems(selectedComponent, selectedLanguage)
      .subscribe(
        products => {
          this.products = products;
          this.dataSource = new MatTableDataSource(products);
          console.log(products);
        },
        error => {
          console.log(error);
        });
  }
}
