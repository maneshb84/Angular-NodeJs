import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {MatTableModule} from '@angular/material/table';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ItemsListComponent } from './components/items-list/items-list.component';
import { ItemsFilterComponent } from './components/items-filter/items-filter.component';

import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HelpPageComponent } from './components/help-page/help-page.component';


@NgModule({
  declarations: [
    AppComponent,
    ItemsListComponent,
    ItemsFilterComponent,
    HelpPageComponent
  ],
  imports: [
    BrowserModule,
    MatTableModule,    
    AppRoutingModule, 
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,     
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ],
  exports: [ItemsFilterComponent],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

// AOT compilation support
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
