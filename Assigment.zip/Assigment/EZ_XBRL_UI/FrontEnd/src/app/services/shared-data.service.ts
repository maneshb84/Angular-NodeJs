import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedDataService {
  conceptId: any; 
  selectedLanguage: any;

  constructor() {
   }

  
  public GetConceptId(): string {     
    return this.conceptId;
  }

  public SetSelectedConceptId(id: String) {    
    this.conceptId = id;
  }


  public GetSelectedLanguage(): string {     
    return this.selectedLanguage;
  }

  public SetSelectedLanguage(language: String) {
    this.selectedLanguage = language;
  }

}
