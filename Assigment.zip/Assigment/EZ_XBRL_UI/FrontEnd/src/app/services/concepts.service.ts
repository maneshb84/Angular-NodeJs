import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfiguration } from "read-appsettings-json";

const currentServiceURL = AppConfiguration.Setting().ApiEndpoint + '/concepts';

@Injectable({
  providedIn: 'root'
})
export class ConceptsService {

constructor(private httpClient: HttpClient) { }

  GetDistinctConcepts(): Observable<any> {
    return this.httpClient.get(currentServiceURL);
  }
}
