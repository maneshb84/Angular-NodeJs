import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConfiguration } from "read-appsettings-json";


const currentServiceURL = AppConfiguration.Setting().ApiEndpoint + '/items';
@Injectable({
  providedIn: 'root'
})
export class ItemsService {

constructor(private httpClient: HttpClient) { }

GetItems(selectedComponent: any, selectedLanguage : any): Observable<any> {
    const params = new HttpParams()
    .set('concept', selectedComponent)
    .set('language', selectedLanguage);
    return this.httpClient.get(currentServiceURL, {params});
  }
}
