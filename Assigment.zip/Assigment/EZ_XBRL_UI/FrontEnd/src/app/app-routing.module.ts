import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ItemsListComponent } from './components/items-list/items-list.component';
import { ItemsFilterComponent } from './components/items-filter/items-filter.component';
import { HelpPageComponent } from './components/help-page/help-page.component';

/*
import { ItemsDetailsComponent } from './components/items-details/items-details.component';
import { ItemsCreateComponent } from './components/items-create/items-create.component';
*/

const routes: Routes = [
  { path: '', redirectTo: 'filter', pathMatch: 'full' },
  // // { path: 'items/:id/:language', component: ItemsListComponent },
  { path: 'items', component: ItemsListComponent },
  { path: 'filter', component: ItemsFilterComponent },
  { path: 'helpPage', component: HelpPageComponent }, 
  // { path: 'landingPage', component: LandingPageComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
