// import required essentials
const express = require('express');
// create new router
const router = express.Router();
const fs = require('fs');


// HTTP methods ↓↓ starts here.
// READ
// this end-point of an API returns JSON data array
router.get('/', function (req, res) {
    fs.readFile('./data/concept.json', 'utf8', (err, jsonString) => {
        res.status(200).json(JSON.parse(jsonString));
    })    
});


// module.exports is an object included in every JS file of Node.js
// application, whatever we assign to module.exports will be exposed as a module. 
module.exports = router;