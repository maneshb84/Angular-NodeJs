// import required essentials
const express = require('express');
// create new router
const router = express.Router();
const fs = require('fs');

// HTTP methods ↓↓ starts here.
// READ
// this end-point of an API returns JSON data 
// Data is passed in query string
router.get('/', function (req, res) {
    let concept = req.query.concept;
    let language = req.query.language;
    fs.readFile('./data/Items.json', 'utf8', (err, jsonString) => {
        const records =  JSON.parse(jsonString);
        const result = records.filter(function(item){
            return item.concept_id == concept && item.language == language;         
        });
        res.status(200).json(result);
    })
});

// READ
// this api end-point gets filtered data by id passed
// id is to passed in params
router.get('/:id', function (req, res) {
    // find an object from `data` array match by `id`
    let id = req.params.id;

    fs.readFile('./data/Items.json', 'utf8', (err, jsonString) => {
        const records =  JSON.parse(jsonString);        
    })


    let found = records.find(function (item) {
        return item.id === parseInt(req.params.id);
    });
    // if object found return an object else return 404 not-found
    if (found) {
        res.status(200).json(found);
    } else {
        res.sendStatus(404);
    }
});

// CREATE
// this api end-point add new object to item list
// that is add item to file
router.post('/', function (req, res) {   
   var newItem;
    fs.readFile('./data/Items.json', 'utf8', (err, jsonString) => {
        if (err){
            console.log(err);
        } else {

        const records =  JSON.parse(jsonString);
        let newId = records.length > 0 ? records.length + 1 : 1;
        // create an object of new Item
         newItem = {
            id: newId, // generated in above step
            label_type_id: req.query.label_type_id, // value of `title` get from POST req
            concept_id: req.query.concept_id, // generated in above step
            label_description: req.query.label_description, // default value is set to false
            language: req.query.language // new date object
        };            
            records.push(newItem); //add some data
            json = JSON.stringify(records); //convert it back to json
            // write it back 
            fs.truncate('./data/Items.json', 0, function(){console.log('done')})
            fs.appendFile('./data/Items.json', json, function (err) {
                if (err) throw err;
                console.log('Saved!');
              });
        }});

    // return with status 201
    // 201 means Created. The request has been fulfilled and 
    // has resulted in one or more new resources being created. 
    res.status(201).json(newItem);
});

// UPDATE
// this api end-point update an existing item object
// for that we get `id` and `title` from api end-point of item to update
router.put('/', function (req, res) {  
   var updated;
    var recordId = req.query.id;
    fs.readFile('./data/Items.json', 'utf8', (err, jsonString) => {
        if (err){
            console.log(err);
        } else {
        // // get item object match by `id`
        // let found = data.find(function (item) {
        //     return item.id === parseInt(recordId);
        // });
        const records =  JSON.parse(jsonString);
        records.some(function(obj){
            if (obj.id === recordId){
                 //change the value here
                 obj.label_type_id = req.query.label_type_id, // value of `title` get from POST req
                 obj.concept_id = req.query.concept_id, // generated in above step
                 obj.label_description = req.query.label_description, // default value is set to false
                 obj. language = req.query.language // new date object
                 return true;    //breaks out of he loop
            }
         });       
        
            json = JSON.stringify(records); //convert it back to json
            // write it back 
            fs.truncate('./data/Items.json', 0, function(){console.log('done')})
            fs.appendFile('./data/Items.json', json, function (err) {
                if (err) throw err;
                console.log('Saved!');
              });
        }});
    res.status(204).json(jsonString);
});

// DELETE
// this api end-point delete an existing item object from
// array of data, match by `id` find item and then delete
router.delete('/:id', function (req, res) {
    // find item from array of data
    let found = data.find(function (item) {
        return item.id === parseInt(req.params.id);
    });

    if (found) {
        // if item found then find index at which the item is
        // stored in the `data` array
        let targetIndex = data.indexOf(found);

        // splice means delete item from `data` array using index
        data.splice(targetIndex, 1);
    }

    // return with status 204
    // success status response code 204 indicates
    // that the request has succeeded
    res.sendStatus(204);
});

// module.exports is an object included in every JS file of Node.js
// application, whatever we assign to module.exports will be exposed as a module. 
module.exports = router;